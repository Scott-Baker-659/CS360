package com.example.cs360project3option1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

public class inventoryDisplay extends AppCompatActivity {

    RecyclerView recyclerView;
    RecyclerView.Adapter ProgramAdapter;

    String[] inventoryNameList = {"A Stick", "Aussie Tool", "Chest", "Fire Arrows", "Hammer", "Heavy Bling",
            "Hookshot", "Hot Sauce", "Lens", "Light Arrows", "Mild Sauce", "Ocarina", "Perk You UP",
            "Shiny Shield", "Slingshot", "Steel Toes", "Strong Bois", "Sword", "Terror Mou5", "Triforce",
            "Wallet", "Wooden Shield"};
    String[] inventoryDescriptionList = {"Its just a stick", "A boomerang always comes back", "Use this to store stuff",
            "Use these to light something far away", "If its still broke, get the biggest hammer!", "Wrist support for heavy loads",
            "Shoot cho Hookshot!", "One drop makes you scream Hyyyaaahh! ", "Helps you see through the lies",
            "Used to enlighten far away people", "Takes you back to a better time", "HEY OCARINA... HYAH!", "You'll feel aaalll better",
            "WOW, much pristine, such reflective!", "A child's play thing", "Great for any hazards on the job site!",
            "Helps you pick things up to put them down", "More like a letter opener", "A rodent with a problem",
            "The most Holiest of relics", "Used to hold lots of tiny green gems", "Keep away from heat..."};

    int[] inventoryImages = {R.drawable.a_stick, R.drawable.aussie_weapon, R.drawable.chest, R.drawable.fire_arrows,
            R.drawable.hammer, R.drawable.heavy_bling, R.drawable.hookshot, R.drawable.hot_sauce, R.drawable.lens,
            R.drawable.light_arrows, R.drawable.mild_sauce, R.drawable.ocarina, R.drawable.perk_you_up, R.drawable.shiny_shield,
            R.drawable.slingshot, R.drawable.steel_toes, R.drawable.strong_bois, R.drawable.sword, R.drawable.terror_mou5,
            R.drawable.triforce, R.drawable.wallet, R.drawable.wooden_shield};

    int itemQTY [] = {30, 10, 2, 50, 4, 6, 3, 15, 10, 50, 15, 8, 2, 1, 13, 5, 3, 11, 25, 1, 20, 3};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_display);
        recyclerView = findViewById(R.id.recView);
        ProgramAdapter = new ProgramAdapter( this, inventoryNameList, inventoryDescriptionList, inventoryImages, itemQTY);
        recyclerView.setAdapter(ProgramAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}