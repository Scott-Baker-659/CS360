package com.example.cs360project3option1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText ed1, ed2;
    private Button btn1;
    private TextView hello;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed1 = findViewById(R.id.user);
        ed1.addTextChangedListener(loginTextWatcher);

        ed2 = findViewById(R.id.password);
        ed2.addTextChangedListener(loginTextWatcher);

        hello = findViewById(R.id.hello);


        btn1 = findViewById(R.id.login);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = ed1.getText().toString();
                hello.setText("Hello " + name);

                openInventoryDisplay();

            }
        });

    }

    //text watcher to enable/disable account buttons
    private TextWatcher loginTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String userNameInput = ed1.getText().toString();
            String password = ed2.getText().toString().trim();

            btn1.setEnabled(!userNameInput.isEmpty() && !password.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    public void openInventoryDisplay(){
        Intent intent = new Intent(this, inventoryDisplay.class);
        startActivity(intent);
    }

}