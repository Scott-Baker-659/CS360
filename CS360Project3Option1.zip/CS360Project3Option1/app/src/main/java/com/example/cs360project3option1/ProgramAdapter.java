package com.example.cs360project3option1;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.BreakIterator;

public class ProgramAdapter extends RecyclerView.Adapter<ProgramAdapter.ViewHolder>{

    String data1[];
    String data2[];
    String qty;
    String tempQty;
    int images[];
    Context context;

    public ProgramAdapter(Context cont, String[] inventoryNameList, String[] inventoryDescriptionList, int[] inventoryImages, int[] itemQTY){
        context = cont;
        data1 = inventoryNameList;
        data2 = inventoryDescriptionList;
        images = inventoryImages;
        tempQty = String.valueOf(itemQTY);
        qty = tempQty;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.single_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        viewHolder.myText1.setText(data1[i]);
        viewHolder.myText2.setText(data2[i]);
        viewHolder.myImage.setImageResource(images[i]);
        viewHolder.myQty.setText("Qty: " + qty[i]);
    }

    @Override
    public int getItemCount() {

        return data1.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{


        TextView myText1, myText2, myQty;
        ImageView myImage;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            myText1 = itemView.findViewById(R.id.textView1);
            myText2 = itemView.findViewById(R.id.textView2);
            myImage = itemView.findViewById(R.id.itemView);
            myQty = itemView.findViewById(R.id.itemQTY);
        }
    }
}
